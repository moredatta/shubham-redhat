/********************************************************************************
** Form generated from reading UI file 'nbiobsp_demo.ui'
**
** Created: Tue May 29 13:36:48 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NBIOBSP_DEMO_H
#define UI_NBIOBSP_DEMO_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NBioBSP_Demo
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *editEIQ;
    QLabel *label_2;
    QLineEdit *editVIQ;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *editMEF;
    QLineEdit *editSPF;
    QLineEdit *editDTO;
    QComboBox *comboSL;
    QLabel *label;
    QPushButton *btSetInit;
    QPushButton *btGetInit;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_7;
    QComboBox *comboDevice;
    QPushButton *btOpen;
    QLabel *label_10;
    QLabel *label_11;
    QLineEdit *editPayload;
    QLabel *label_12;
    QLabel *label_13;
    QComboBox *comboDataType;
    QPushButton *btVerify;
    QLabel *labelStatus;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QPushButton *btCapture;
    QLabel *FPReg;
    QLabel *FPVerify;

    void setupUi(QDialog *NBioBSP_Demo)
    {
        if (NBioBSP_Demo->objectName().isEmpty())
            NBioBSP_Demo->setObjectName(QString::fromUtf8("NBioBSP_Demo"));
        NBioBSP_Demo->resize(759, 487);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(NBioBSP_Demo->sizePolicy().hasHeightForWidth());
        NBioBSP_Demo->setSizePolicy(sizePolicy);
        NBioBSP_Demo->setMinimumSize(QSize(759, 487));
        NBioBSP_Demo->setMaximumSize(QSize(759, 487));
        NBioBSP_Demo->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        layoutWidget = new QWidget(NBioBSP_Demo);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 533, 477));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        editEIQ = new QLineEdit(layoutWidget);
        editEIQ->setObjectName(QString::fromUtf8("editEIQ"));
        editEIQ->setMaxLength(3);
        editEIQ->setFrame(true);
        editEIQ->setCursorPosition(0);

        gridLayout->addWidget(editEIQ, 1, 1, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        editVIQ = new QLineEdit(layoutWidget);
        editVIQ->setObjectName(QString::fromUtf8("editVIQ"));
        editVIQ->setMaxLength(3);

        gridLayout->addWidget(editVIQ, 2, 1, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 3, 0, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 4, 0, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 5, 0, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 6, 0, 1, 1);

        editMEF = new QLineEdit(layoutWidget);
        editMEF->setObjectName(QString::fromUtf8("editMEF"));
        editMEF->setMaxLength(2);

        gridLayout->addWidget(editMEF, 3, 1, 1, 1);

        editSPF = new QLineEdit(layoutWidget);
        editSPF->setObjectName(QString::fromUtf8("editSPF"));
        editSPF->setEnabled(true);
        editSPF->setMaxLength(3);
        editSPF->setReadOnly(true);

        gridLayout->addWidget(editSPF, 4, 1, 1, 1);

        editDTO = new QLineEdit(layoutWidget);
        editDTO->setObjectName(QString::fromUtf8("editDTO"));
        editDTO->setMaxLength(6);

        gridLayout->addWidget(editDTO, 5, 1, 1, 1);

        comboSL = new QComboBox(layoutWidget);
        comboSL->setObjectName(QString::fromUtf8("comboSL"));

        gridLayout->addWidget(comboSL, 6, 1, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 1, 0, 1, 1);

        btSetInit = new QPushButton(layoutWidget);
        btSetInit->setObjectName(QString::fromUtf8("btSetInit"));
        btSetInit->setEnabled(false);

        gridLayout->addWidget(btSetInit, 1, 2, 1, 1);

        btGetInit = new QPushButton(layoutWidget);
        btGetInit->setObjectName(QString::fromUtf8("btGetInit"));
        btGetInit->setEnabled(false);

        gridLayout->addWidget(btGetInit, 2, 2, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 8, 0, 1, 1);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 9, 0, 1, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 0, 0, 1, 1);

        comboDevice = new QComboBox(layoutWidget);
        comboDevice->setObjectName(QString::fromUtf8("comboDevice"));

        gridLayout->addWidget(comboDevice, 9, 1, 1, 1);

        btOpen = new QPushButton(layoutWidget);
        btOpen->setObjectName(QString::fromUtf8("btOpen"));
        btOpen->setEnabled(false);

        gridLayout->addWidget(btOpen, 9, 2, 1, 1);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout->addWidget(label_10, 11, 0, 1, 1);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 12, 0, 1, 1);

        editPayload = new QLineEdit(layoutWidget);
        editPayload->setObjectName(QString::fromUtf8("editPayload"));

        gridLayout->addWidget(editPayload, 12, 1, 1, 1);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout->addWidget(label_12, 15, 0, 1, 1);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout->addWidget(label_13, 16, 0, 1, 1);

        comboDataType = new QComboBox(layoutWidget);
        comboDataType->setObjectName(QString::fromUtf8("comboDataType"));

        gridLayout->addWidget(comboDataType, 16, 1, 1, 1);

        btVerify = new QPushButton(layoutWidget);
        btVerify->setObjectName(QString::fromUtf8("btVerify"));
        btVerify->setEnabled(false);

        gridLayout->addWidget(btVerify, 16, 2, 1, 1);

        labelStatus = new QLabel(layoutWidget);
        labelStatus->setObjectName(QString::fromUtf8("labelStatus"));

        gridLayout->addWidget(labelStatus, 18, 0, 1, 3);

        line = new QFrame(layoutWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line, 7, 0, 1, 3);

        line_2 = new QFrame(layoutWidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_2, 10, 0, 1, 3);

        line_3 = new QFrame(layoutWidget);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_3, 14, 0, 1, 3);

        line_4 = new QFrame(layoutWidget);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_4, 17, 0, 1, 3);

        btCapture = new QPushButton(layoutWidget);
        btCapture->setObjectName(QString::fromUtf8("btCapture"));
        btCapture->setEnabled(false);

        gridLayout->addWidget(btCapture, 12, 2, 1, 1);

        FPReg = new QLabel(NBioBSP_Demo);
        FPReg->setObjectName(QString::fromUtf8("FPReg"));
        FPReg->setGeometry(QRect(550, 30, 200, 200));
        FPReg->setFrameShape(QFrame::WinPanel);
        FPVerify = new QLabel(NBioBSP_Demo);
        FPVerify->setObjectName(QString::fromUtf8("FPVerify"));
        FPVerify->setGeometry(QRect(550, 250, 200, 200));
        FPVerify->setFrameShape(QFrame::WinPanel);
        QWidget::setTabOrder(editEIQ, editVIQ);
        QWidget::setTabOrder(editVIQ, editMEF);
        QWidget::setTabOrder(editMEF, editSPF);
        QWidget::setTabOrder(editSPF, editDTO);
        QWidget::setTabOrder(editDTO, comboSL);
        QWidget::setTabOrder(comboSL, btGetInit);

        retranslateUi(NBioBSP_Demo);

        QMetaObject::connectSlotsByName(NBioBSP_Demo);
    } // setupUi

    void retranslateUi(QDialog *NBioBSP_Demo)
    {
        NBioBSP_Demo->setWindowTitle(QApplication::translate("NBioBSP_Demo", "NBioBSP_Demo", 0, QApplication::UnicodeUTF8));
        editEIQ->setInputMask(QApplication::translate("NBioBSP_Demo", "999; ", 0, QApplication::UnicodeUTF8));
        editEIQ->setText(QString());
        label_2->setText(QApplication::translate("NBioBSP_Demo", "Verify Image Quality", 0, QApplication::UnicodeUTF8));
        editVIQ->setInputMask(QApplication::translate("NBioBSP_Demo", "999; ", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("NBioBSP_Demo", "Max Enroll Finger", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("NBioBSP_Demo", "Sample per Finger", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("NBioBSP_Demo", "Default Timeout", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("NBioBSP_Demo", "Security Level", 0, QApplication::UnicodeUTF8));
        editMEF->setInputMask(QApplication::translate("NBioBSP_Demo", "99; ", 0, QApplication::UnicodeUTF8));
        editSPF->setInputMask(QApplication::translate("NBioBSP_Demo", "999; ", 0, QApplication::UnicodeUTF8));
        editDTO->setInputMask(QApplication::translate("NBioBSP_Demo", "999999; ", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("NBioBSP_Demo", "Enroll Image Quality", 0, QApplication::UnicodeUTF8));
        btSetInit->setText(QApplication::translate("NBioBSP_Demo", "Set Initial Info", 0, QApplication::UnicodeUTF8));
        btGetInit->setText(QApplication::translate("NBioBSP_Demo", "Get Initial Info", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("NBioBSP_Demo", "Device", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("NBioBSP_Demo", "Device List", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("NBioBSP_Demo", "Initialization", 0, QApplication::UnicodeUTF8));
        btOpen->setText(QApplication::translate("NBioBSP_Demo", "Open", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("NBioBSP_Demo", "Registration", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("NBioBSP_Demo", "Payload Value", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("NBioBSP_Demo", "Verify", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("NBioBSP_Demo", "FIR Data Type", 0, QApplication::UnicodeUTF8));
        btVerify->setText(QApplication::translate("NBioBSP_Demo", "Verify", 0, QApplication::UnicodeUTF8));
        labelStatus->setText(QApplication::translate("NBioBSP_Demo", "Status Text", 0, QApplication::UnicodeUTF8));
        btCapture->setText(QApplication::translate("NBioBSP_Demo", "Capture", 0, QApplication::UnicodeUTF8));
        FPReg->setText(QString());
        FPVerify->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class NBioBSP_Demo: public Ui_NBioBSP_Demo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NBIOBSP_DEMO_H
