/****************************************************************************
** Meta object code from reading C++ file 'nbiobsp_dataconvert.h'
**
** Created: Fri Apr 20 17:12:25 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "nbiobsp_dataconvert.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'nbiobsp_dataconvert.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NBioBSP_DataConvert[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      21,   20,   20,   20, 0x08,
      43,   20,   20,   20, 0x08,
      63,   20,   20,   20, 0x08,
      83,   20,   20,   20, 0x08,
     111,  105,   20,   20, 0x08,
     161,  153,   20,   20, 0x08,
     187,  153,   20,   20, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_NBioBSP_DataConvert[] = {
    "NBioBSP_DataConvert\0\0on_btImport_pressed()\0"
    "on_btLoad_pressed()\0on_btSave_pressed()\0"
    "on_btExport_pressed()\0index\0"
    "on_comboDataType_currentIndexChanged(int)\0"
    "checked\0on_rdImport_toggled(bool)\0"
    "on_rdExport_toggled(bool)\0"
};

const QMetaObject NBioBSP_DataConvert::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_NBioBSP_DataConvert,
      qt_meta_data_NBioBSP_DataConvert, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NBioBSP_DataConvert::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NBioBSP_DataConvert::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NBioBSP_DataConvert::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NBioBSP_DataConvert))
        return static_cast<void*>(const_cast< NBioBSP_DataConvert*>(this));
    return QDialog::qt_metacast(_clname);
}

int NBioBSP_DataConvert::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_btImport_pressed(); break;
        case 1: on_btLoad_pressed(); break;
        case 2: on_btSave_pressed(); break;
        case 3: on_btExport_pressed(); break;
        case 4: on_comboDataType_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: on_rdImport_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: on_rdExport_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 7;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
