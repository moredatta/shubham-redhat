/********************************************************************************
** Form generated from reading UI file 'nbiobsp_dataconvert.ui'
**
** Created: Fri Apr 20 17:12:23 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NBIOBSP_DATACONVERT_H
#define UI_NBIOBSP_DATACONVERT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_NBioBSP_DataConvert
{
public:
    QFrame *frame;
    QLabel *label;
    QRadioButton *rdExport;
    QRadioButton *rdImport;
    QFrame *frame_2;
    QLabel *label_2;
    QComboBox *comboDataType;
    QLabel *label_3;
    QLineEdit *editTemplateSize;
    QFrame *frame_3;
    QLabel *label_4;
    QPushButton *btExport;
    QPushButton *btSave;
    QFrame *frame_4;
    QLabel *label_5;
    QPushButton *btLoad;
    QPushButton *btImport;
    QLabel *labelStatus;
    QLabel *labelFP;

    void setupUi(QDialog *NBioBSP_DataConvert)
    {
        if (NBioBSP_DataConvert->objectName().isEmpty())
            NBioBSP_DataConvert->setObjectName(QString::fromUtf8("NBioBSP_DataConvert"));
        NBioBSP_DataConvert->resize(809, 442);
        NBioBSP_DataConvert->setMinimumSize(QSize(809, 442));
        NBioBSP_DataConvert->setMaximumSize(QSize(809, 442));
        frame = new QFrame(NBioBSP_DataConvert);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(10, 10, 581, 71));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 10, 91, 17));
        rdExport = new QRadioButton(frame);
        rdExport->setObjectName(QString::fromUtf8("rdExport"));
        rdExport->setGeometry(QRect(20, 40, 147, 22));
        rdImport = new QRadioButton(frame);
        rdImport->setObjectName(QString::fromUtf8("rdImport"));
        rdImport->setGeometry(QRect(240, 40, 147, 22));
        frame_2 = new QFrame(NBioBSP_DataConvert);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(10, 85, 581, 121));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 10, 71, 17));
        comboDataType = new QComboBox(frame_2);
        comboDataType->setObjectName(QString::fromUtf8("comboDataType"));
        comboDataType->setGeometry(QRect(10, 40, 561, 27));
        comboDataType->setMaxVisibleItems(20);
        label_3 = new QLabel(frame_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 91, 171, 17));
        editTemplateSize = new QLineEdit(frame_2);
        editTemplateSize->setObjectName(QString::fromUtf8("editTemplateSize"));
        editTemplateSize->setGeometry(QRect(185, 85, 381, 27));
        frame_3 = new QFrame(NBioBSP_DataConvert);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(10, 210, 581, 101));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label_4 = new QLabel(frame_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 10, 121, 17));
        btExport = new QPushButton(frame_3);
        btExport->setObjectName(QString::fromUtf8("btExport"));
        btExport->setEnabled(false);
        btExport->setGeometry(QRect(40, 40, 221, 41));
        btSave = new QPushButton(frame_3);
        btSave->setObjectName(QString::fromUtf8("btSave"));
        btSave->setEnabled(false);
        btSave->setGeometry(QRect(320, 40, 221, 41));
        frame_4 = new QFrame(NBioBSP_DataConvert);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setGeometry(QRect(10, 315, 581, 101));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        label_5 = new QLabel(frame_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 10, 121, 17));
        btLoad = new QPushButton(frame_4);
        btLoad->setObjectName(QString::fromUtf8("btLoad"));
        btLoad->setEnabled(false);
        btLoad->setGeometry(QRect(43, 40, 221, 41));
        btImport = new QPushButton(frame_4);
        btImport->setObjectName(QString::fromUtf8("btImport"));
        btImport->setEnabled(false);
        btImport->setGeometry(QRect(320, 40, 221, 41));
        labelStatus = new QLabel(NBioBSP_DataConvert);
        labelStatus->setObjectName(QString::fromUtf8("labelStatus"));
        labelStatus->setGeometry(QRect(4, 420, 801, 20));
        labelStatus->setFrameShape(QFrame::StyledPanel);
        labelFP = new QLabel(NBioBSP_DataConvert);
        labelFP->setObjectName(QString::fromUtf8("labelFP"));
        labelFP->setGeometry(QRect(600, 120, 200, 200));
        labelFP->setFrameShape(QFrame::WinPanel);

        retranslateUi(NBioBSP_DataConvert);

        QMetaObject::connectSlotsByName(NBioBSP_DataConvert);
    } // setupUi

    void retranslateUi(QDialog *NBioBSP_DataConvert)
    {
        NBioBSP_DataConvert->setWindowTitle(QApplication::translate("NBioBSP_DataConvert", "NBioBSP_DataConvert", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("NBioBSP_DataConvert", "Test Operation", 0, QApplication::UnicodeUTF8));
        rdExport->setText(QApplication::translate("NBioBSP_DataConvert", "Export Function Test", 0, QApplication::UnicodeUTF8));
        rdImport->setText(QApplication::translate("NBioBSP_DataConvert", "Import Function Test", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("NBioBSP_DataConvert", "Data Type", 0, QApplication::UnicodeUTF8));
        comboDataType->clear();
        comboDataType->insertItems(0, QStringList()
         << QApplication::translate("NBioBSP_DataConvert", "FDP(FDU)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FDA", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FDA(Old Version)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FDAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FIM10-HV / FIM10-LV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FIM01-HV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FIM01-HD", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "FeliCa", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "Extension(Max 1024bytes)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "Variable Size", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "ANSI", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("NBioBSP_DataConvert", "ISO", 0, QApplication::UnicodeUTF8)
        );
        label_3->setText(QApplication::translate("NBioBSP_DataConvert", "Template Size(Variable Size)", 0, QApplication::UnicodeUTF8));
        editTemplateSize->setInputMask(QApplication::translate("NBioBSP_DataConvert", "999; ", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("NBioBSP_DataConvert", "Export Function Test", 0, QApplication::UnicodeUTF8));
        btExport->setText(QApplication::translate("NBioBSP_DataConvert", "Capture & Export", 0, QApplication::UnicodeUTF8));
        btSave->setText(QApplication::translate("NBioBSP_DataConvert", "Save", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("NBioBSP_DataConvert", "Import Function Test", 0, QApplication::UnicodeUTF8));
        btLoad->setText(QApplication::translate("NBioBSP_DataConvert", "Load", 0, QApplication::UnicodeUTF8));
        btImport->setText(QApplication::translate("NBioBSP_DataConvert", "Import & Verify", 0, QApplication::UnicodeUTF8));
        labelStatus->setText(QApplication::translate("NBioBSP_DataConvert", "Status", 0, QApplication::UnicodeUTF8));
        labelFP->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class NBioBSP_DataConvert: public Ui_NBioBSP_DataConvert {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NBIOBSP_DATACONVERT_H
